return {
  {
    "folke/snacks.nvim",
    opts = {
      picker = {
        ui_select = true,
        sources = {
          explorer = {
            hidden = true,
            ignored = true,
            auto_close = false,
            reuse_win = true,
            win = {
              list = {
                keys = {
                  ["o"] = "confirm", -- open file to edit (same as <CR>)
                  ["O"] = "explorer_open", -- keep system-open on a different key (optional)
                  ["<Esc>"] = false,
                },
              },
            },
          },
        },
      },
      dashboard = {
        enabled = true,
        preset = {
          header = [[
███╗   ██╗███████╗ ██████╗ ██╗   ██╗██╗███╗   ███╗
████╗  ██║██╔════╝██╔═══██╗██║   ██║██║████╗ ████║
██╔██╗ ██║█████╗  ██║   ██║██║   ██║██║██╔████╔██║
██║╚██╗██║██╔══╝  ██║   ██║╚██╗ ██╔╝██║██║╚██╔╝██║
██║ ╚████║███████╗╚██████╔╝ ╚████╔╝ ██║██║ ╚═╝ ██║
╚═╝  ╚═══╝╚══════╝ ╚═════╝   ╚═══╝  ╚═╝╚═╝     ╚═╝]],
        },
      },
      explorer = {},
    },
  },
}
